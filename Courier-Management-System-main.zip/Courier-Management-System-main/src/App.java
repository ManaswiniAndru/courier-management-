public class App {
    public static void main(String[] args) throws Exception {
        //new Order();
        new jdbctrail();
        new Home();
        //System.out.println("Hello, World!");
    }
}
