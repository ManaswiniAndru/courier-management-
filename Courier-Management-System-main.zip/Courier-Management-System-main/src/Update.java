import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.*;
public class Update {
    
    JFrame f1;
    JTextArea result;
    JButton Checkorders,update,back;
    Update()
    {
        f1=new JFrame("Orders");
        f1.setLayout(null);
        f1.setVisible(true);
        f1.getContentPane().setBackground(Color.gray);
        String r="";
        StringBuilder s=new StringBuilder();







        f1.setLayout(null);
        f1.setVisible(true);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setSize(700,500);
        f1.setLocationRelativeTo(null);



    }

}
